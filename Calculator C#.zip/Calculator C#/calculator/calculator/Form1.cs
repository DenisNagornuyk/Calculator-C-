﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region SettingsFrom
        //перевірка клацтнутої кнопкі
        private bool isClickMouse = false;
        //позиція миши
        private Point currentPosition = new Point(0,0);

        private void label2_Click(object sender, EventArgs e)
        {

        }
        //кнопка закриття
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isClickMouse = false;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isClickMouse = true;
            //поточна позиція нової точки Х та Y (е - це параметер точки)
            currentPosition = new Point(e.X, e.Y);
        }
        //переміщення затистнутої миши
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isClickMouse) { return; }
            Point buf = new Point(this.Location.X, this.Location.Y);

            buf.X += e.X - currentPosition.X;
            buf.Y += e.Y - currentPosition.Y;
            #endregion
        }
        //створюємо приватний класс типу зривняння та рівності в положення false
        private bool isPoint = false;
        private bool isNum2 = false;
        //приватна сторока першого числа яке приводим в нульове значення
        private string Num1 = null;
        private string Num2 = null;
        //створюємо поточну операцію
        private string currentOperation = "";
        //void локальна функція
        private void AddNum(string txt)
        {
            if (isNum2)
            {
                //присвоєння додавання +=
                Num2 += txt;
                textResult.Text = Num2;
            }
            else
            {
                Num1 += txt;
                textResult.Text = Num1;
            }
        }
        private void SetNum(string txt)
        {
            if (isNum2)
            {
                Num2 = txt;
                textResult.Text = Num2;
            }
            else
            {
                Num1 = txt;
                textResult.Text = Num1;
            }
        }

        private void buttonNumverClick(object obj, EventArgs e)
        {
            //var дозволяє оголошувати локальну змінну в випадку (txt)
            var txt = ((Button)obj).Text;
            {
                //логічнмй оператор (&&) повертає значення в true, якщо два операнда = true и повертають false у неприємний випадок
                //&& це - true false 
                // (==) перевіряє рівня ці значення
                if (isPoint && txt == ",") { return; }
                //якщо txt прирівнюється то  isPoint який був ложним стає дійсним, тобто з false -> true
                if (txt == ",") { isPoint = true; }
            }
            if (txt == "+/-")
            {
                //Length повертає число знаків в поточний обьєкт типу String
                if (textResult.Text.Length > 0)
                    if (textResult.Text[0] == '-')
                    {
                        //Substring - витягує підрядок з цього екземпляра.  підрядок починається з зазначеної позиції знака і має вказану довжину,
                        //тобто повернення йде в рядок, еквалінтне підстроювання довжиною перетворення числа знаків у поточний об'єкт, 
                        //яка починається з StartIndex в даному екземплярі або в рядку Empty якщо значення стартового індексу дорівнює довжині даного екземпляра, 
                        //а значення  Length = 0
                        //тому ми вказуємо в результаті тексту довжину - 1
                        textResult.Text = textResult.Text.Substring(1, textResult.Text.Length - 1);
                    }
                    else
                    {
                        //функція віднімання
                        textResult.Text = "-" + textResult.Text;
                    }
                //створює число за взазаним результатом
                SetNum(textResult.Text);
                return;
            }
            AddNum(txt);
        }

        //кнопка за математичні дії
        private void buttonOperationClick(object obj,EventArgs e)
        {
            //перевірка точно числа
            if(Num1 == null) { if (textResult.Text.Length > 0) Num1 = textResult.Text; else return; }
            isNum2 = true;
            currentOperation = ((Button)obj).Text;
            SetResult(currentOperation);
        }

        private void SetResult(string operation)
        {
            string result = null;

            switch (operation)
            {
                //MathOperation клас для математичних дії
                case "+": { result = MathOperation.Add(Num1, Num2); break; }
                case "-": { result = MathOperation.Sub(Num1, Num2); break; }
                case "x": { result = MathOperation.Mul(Num1, Num2); break; }
                case "/": { result = MathOperation.Dev(Num1, Num2); break; }
                case "%": { result = MathOperation.Proc(Num1, Num2); break; }
                case "OK": { result = MathOperation.Sqr(Num1); isNum2 = false; break; }
                case "x2": { result = MathOperation.Pow(Num1); isNum2 = false; break; }
                case "1/x": { result = MathOperation.OneDev(Num1); isNum2 = false; break; }
                default: break;
            }
            OutputResult(result, operation);
            if (isNum2) { if (result != null) Num1 = result; } else { Num1 = null; }
            isPoint = false;
        }
        //метод виводу результату та історії
        private void OutputResult(string result, string operation)
        {
            switch (operation)
            {
                case "OK": { if (Num1 != null) textHistory.Text = "OK" + Num1 + " = "; break; }
                case "x2": { if (Num1 != null) textHistory.Text = Num1 + " = "; break; }
                case "1/": { if (Num1 != null) textHistory.Text = "1/" + Num1 + " = "; break; }
                default:
                    {
                        if(Num2 != null)
                        {
                            textHistory.Text = Num1 + " " + operation + " " + Num2 + "=";
                        }
                        else
                        {
                            if(Num1 != null)
                            {
                                textHistory.Text = Num1 + " " + operation + " ";
                                break;
                            }
                        }
                    }
                    break;
            }

            Num2 = null;
            if(result != null)
            {
                textResult.Text = result;
            }
        }
        //копка видалення поля
        private void buttonClear(object obj, EventArgs e)
        {
            textResult.Text = "";
            textHistory.Text = "";
            isNum2 = false;
            currentOperation = null;
            Num1 = null;
            Num2 = null;
            isPoint = false;
        }
        //копка рівне
        private void buttonResultClick(object obj, EventArgs e)
        {
            SetResult(currentOperation);
            isNum2 = false;
            Num1 = null;
            Num2 = null;
        }
        //по знаково видалення
        private void buttonResetNumber(object obj, EventArgs e)
        {
            if(textResult.Text.Length <=0) { return; }
            textResult.Text = textResult.Text.Substring(0, textResult.Text.Length - 1);
            SetNum(textResult.Text);
        }
    }
}

